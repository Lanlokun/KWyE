<?php 

    include 'inc/functions.php';
    
    $auth = $get_auth(); 
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="index.css" type="text/css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $get_app_title("Home Page") ?></title>
</head>
<body>
    <header>
    <div id="main">
        <div class="logo">
            <img src="./admin/Images/logo.png">
        <div>

        <ul>
            <li class="active"><a href="#">Home</a></li>
            <li><a href="#">Post</a></li>
            <li><a href="#">Food</a></li>
        </ul>
    
    </div>
    </header>
    <div class="title">
    <h1>Welcome Foodie!</h1>
    <div>

    <?php if ($is_logged_in()) { ?>

        <a href="admin">Admin</a>
        <a href="admin/logout.php">Logout</a>

        <strong><?= $auth[ 'name'] ?></strong>

    <?php } else { ?>
        <div class="button">
       
            <a href="admin/login.php" id="btn1" class="btn">Login</a>
             <a href="admin/register.php" id="btn2" class="btn">Register</a>
       </div>

    <?php } ?>
</body>
</html>