<?php 
    include '../inc/functions.php';

    $kick_out_if_logged_in();

    $msg = "";
    if (isset($_POST['register']) && !empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['password'])) {
        
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $password_hash($_POST['password']);
        

        $insert_id = $db_insert(
            "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')"
        );

        if ($insert_id === NULL)
            $msg = 'Email already registered.';
        else {
            $msg = 'Succesfully registered.';
            
            $login($insert_id);
        }
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <link rel="stylesheet" href="register.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $get_app_title("Registration") ?></title>
</head>
<body>
    <div class="logo">
            <img src="logo.png">
     <div>
     <div class="register">

    <h1>Register Here</h1>
    <h3><?= $msg ?></h3>
    
    <div class="form-box">

     <form action="" method="post">
            <p>Full Name</p>
            <input id="FName" type = "text"
               name = "name" placeholder = "Full Name" 
               required autofocus></br></br>
               <p> Email</p>
               <input id="mail" type = "email"
               name = "email" placeholder = "email" 
               required autofocus></br></br>
               <p>Password</p>
            <input id="pass" type = "password"
               name = "password" placeholder = "password" required></br></br>

            <button id="reg" type = "submit" name="register">Register</button>
   </form>
    </div>
    </div>

    

</body>
</html>