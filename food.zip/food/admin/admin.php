<?php
  include '../inc/functions.php'; 

  

?>

<!DOCTYPE html>
<html lang="en">
<head>   
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
         <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
         <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
         <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
            
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $get_app_title("Admin") ?></title>
</head>
<div id="navbar">
    <ul class="nav nav-pills">
        <li class="nav-item">
          <a class="nav-link active" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Food</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Post</a>
        </li>
      </ul>
    </div>
    <header class="header">
        <div class="page-header">
            <h1>Welcome FOODIE!</h1>
          </div>
    </header>
<body>
    <h1 id="headline">KNOW WHAT YOU EAT</h1>
        <div class="search-box">
            <input class="search-txt" type="search" name="" placeholder="Search Food">
            <a class="search-btn" href="#"></a>
            <i class="fa fa-search" aria-hidden="true"></i>
        </div>

    <h1>Admin Page</h1>
    <a href="logout.php">Logout</a>
    <strong><?= $auth['name'] ?></strong>


</body>
</html>