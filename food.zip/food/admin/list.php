<?php 

    include '../inc/functions.php'; 

    $kick_out_if_logged_out();
    
    $auth = $get_auth();

    $results = $db_select(
        "SELECT * FROM food"
    );

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="search.css">
    <script src="search.js"></script>
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $get_app_title("Admin") ?></title>
</head>

<header class="header">
        <div class="logo">
            <img src="logo.png">
        </div>
    
        <div id="main"> 

             <ul>
                <li class="active"><a href="index.php ">Home</a></li>
                <li><a href="post.php">Post</a></li>
                <li><a href="food.php">Food</a></li>
                 </ul>
    
        </div>
        </header>
        <body>
        <div class="logout">
            <button id="log"><ahref="logout.php">Logout</a></button>
        </div>

        <div class="page-header">
            <h1 id="first-h1">Welcome <strong><?= $auth['name'] ?></strong></h1>
            
        </div>
       
        


        <?php foreach($results as $result) { ?>

                <h1>
                   DISH: <?= $result['name'] ?>
                </h1>

               <div id="images">
                <img id="image" src="<?= $result['Image'] ?>"></br></br>
                </div>
                
            
            <div class="content">
                <a href="dish.php?q=<?=$result['id'] ?>" class="button">content</a>
          
                <a href="#" class="button">Delete</a>
          
               
                <a href="post.php" class="button">Update</a>
           
                </div>
                
        <?php } ?>
        

</body>

<footer>
    <p id="quote">Food is life so wake up and eat, eat and eat</p>
    <img src="Images/lery.png" width="50px">
    <img src="Images/cut.png" width="50px">
    <img src="Images/fork.png" width="50px">
    <img src="Images/spoon.png" width="50px">
</footer>
</html>