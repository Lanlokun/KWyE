<?php 

    include '../inc/functions.php'; 

    $kick_out_if_logged_out();
    
    $auth = $get_auth(); 

    $results = [];

    $search = '';
   

    if (isset($_GET['search'])) {

        $search = $_GET['search'];

        $results = $db_select(
            "SELECT * FROM food WHERE name LIKE '%$search%'"
        );
        
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="search.css">
    <script src="search.js"></script>
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $get_app_title("Admin") ?></title>
</head>

<header class="header">
        <div class="logo">
            <img src="logo.png">
        </div>
    
        <div id="main"> 

             <ul>
                <li class="active"><a href="index.php ">Home</a></li>
                <li><a href="post.php">Post</a></li>
                <li><a href="food.php">Food</a></li>
             </ul>
    
        </div>
        </header>

    <body>
        <div class="logout">
            <button id="log"><ahref="logout.php">Logout</a></button>
        </div>

        
        <div class="page-header">
            <h1 id="first-h1">Welcome <strong><?= $auth['name'] ?></strong></h1>
            
        </div>
        <div class="page">
    <div id="lst">
        <a id="list" href="list.php">Show all</a>
   </div>

       
       


        <?php foreach($results as $result) { ?>

           
                <h1 id="dish">
                   DISH:  <?= $result['name'] ?>
                </h1>
                <div id="images">
                <img id="image" src="<?= $result['Image'] ?>"></br></br>
                </div>

                <div id="content">
                <a href="dish.php?q=<?=$result['id'] ?>" class="button">content</a>
                </div>
        </div>
                
                
                
           
            
                
        <?php } ?>

       
</body>
<div class="footer">
<footer>
    <p id="quote">Food is life so wake up and eat, eat and eat</p>
</footer>
        </div>
</html>