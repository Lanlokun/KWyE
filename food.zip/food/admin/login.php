<?php 

    include '../inc/functions.php'; 

    $kick_out_if_logged_in();


    $msg = "";
    if (isset($_POST['login']) && !empty($_POST['email']) && !empty($_POST['password'])) {
        
        $email = $_POST['email'];
        $password = $password_hash($_POST['password']);

        $data = $db_select(
            "SELECT id FROM users WHERE email='$email' AND password='$password'"
        );

        if (count($data) === 1) {
            $login($data[0]['id']);
            

        }else {
            $msg = 'Wrong username or password';
        }

    }


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="login.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $get_app_title("Login") ?></title>
</head>

<body>
<img src="./Images/ava.png" class="avatar">
<div class="login-box">

    <h1>Login Page</h1>

    <form action="" method="post">
            <h4><?= $msg ?></h4>
            <p>User Email</p></br></br>
            <input id="mail" type ="email"
               name = "email" placeholder = "Email" 
               required autofocus></br></br>
               <p>Password</p></br></br>
            <input id="pass" type ="password"
               name = "password" placeholder = "password = 1234" required></br></br>
            <button id="log" type ="submit" name="login">Login</button></br></br>
            <a href="#">Forgot your password</a>
            <a href="#">Click for help</a>
        
         </form>

</div>
</body>
</html>