<?php
     //include 'inc/functions.php';

     $conn = new mysqli('localhost','malik', '12345', 'foodie');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
 // echo "Connected successfully";

 $errors = [];

$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$target_file = $target_dir. time() .'.'. $imageFileType;

// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  if($check !== false) {
    // echo "File is an image - " . $check["mime"] . ".";
    $uploadOk = 1;
  } else {
      array_push($errors, "File is not an image.");
    $uploadOk = 0;
  }


// Check if file already exists
if (file_exists($target_file)) {
    array_push($errors, "Sorry, file already exists.");
  $uploadOk = 0;
}

// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    array_push($errors, "Sorry, your file is too large.");
    $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    array_push($errors, "Sorry, only JPG, JPEG, PNG & GIF files are allowed.");
  $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
      
    
    $sql = "INSERT INTO food (name, ingredient, mealtype, nutritions, type, image, recipe, calories) 
    VALUES ('".$_POST['Foodname']."','".$_POST['ingredients']."','".
    $_POST['mealtype']."','".$_POST['nutrients']."','".$_POST['foodtype']."','".$target_file."','".$_POST['message']."','".$_POST['calories']."')";

    // go to home page


    if ($conn->query($sql) === TRUE) {
        //echo "Submitted successfully";
      } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }


   // echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
  } else {
    echo "Sorry, there was an error uploading your file.";
  }
}
}

  
  $conn->close();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="post.css" type="text/css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post</title>
</head>
<header>
    
        <ul>
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="#">Post</a></li>
            <li><a href="food.php">Food</a></li>
        </ul>
    
    <div id="main">
        <div class="logo">
            <img src="logo.png">
    </div>
 </header>
   
 <body>

    <?php foreach($errors as $error) { ?>
        <li>
            <code><?= $error ?></code>
        </li>
    <?php } ?>

    <h1 id="first-h1">What will you like to post</h1>
    <div class="main">
    <form action="" method="post" enctype="multipart/form-data">
    
  
           <div id="name">
            <p class="fname">Food Name</p>
            <input class="Food" type ="text"
               name = "Foodname" placeholder = "Name Of FOOD" 
               required autofocus></br></br>
           </div>
               <p class="mealtype">Meal Type</p>
            <input id="Meal" type ="text"
               name = "mealtype" placeholder = "Meal Type" required></br></br>
               <p class="ingredients">Ingredients</p>
               <input id="ingredients" type ="text"
               name = "ingredients" placeholder = "Ingredients" required></br></br>
               <p class="nutrients">Nutrients</p>
            <input id="nutrients" type ="text"
               name = "nutrients" placeholder = "Food nutrients" 
               required autofocus></br></br>
               <p class="type">Food Type</p>
               <input id="type" type ="text"
               name = "foodtype" placeholder = "Food Type" 
               required autofocus></br></br>
               <p class="calories">Calories</p>
            <input id="calories" type ="text"
               name = "calories" placeholder = "Calories" 
               required autofocus></br></br>

               <p> Enter The Recipe</p>
               <textarea name="message" rows="10" cols="30"></textarea>
              <br><br>
              
            Select image to upload:
                 <input type="file" name="fileToUpload" id="fileToUpload"></br></br>
       
               
            <button id="log" type ="submit" name="submit">Post</button></br></br>
        
         </form>
    </div>

    
</body>
</html>