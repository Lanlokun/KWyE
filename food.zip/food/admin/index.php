<?php 

    include '../inc/functions.php'; 

    $kick_out_if_logged_out();
    
    $auth = $get_auth();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="admin.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $get_app_title("Admin") ?></title>
</head>

<body>
        <div class="logo">
            <img src="logo.png">
        </div>
    <header class="header">
        <div class="btn">
            <button id="log"><a id="butt" href="logout.php">Logout</a></button>
        </div>
        <div id="main"> 

             <ul>
                <li class="active"><a href="#">Home</a></li>
                <li><a href="post.php">Post</a></li>
                <li><a href="food.php">Food</a></li>
                 </ul>
    
        </div>

        <div class="page-header">
            <h1 id="first-h1">Welcome FOODIE!</h1>
            <h1 id="second-h2">Hello Admin  <strong><?= $auth['name'] ?></strong></h1>
        </div>
        <h1 id="headline">KNOW WHAT YOU EAT</h1>
        <form class="search-box" method="GET" action="search.php">
        <i class="fa fa-search" aria-hidden="true"></i>
            <input class="search-txt" type="search" name="search" value="" placeholder="Search Food">
            <button id="btn1" type="submit">Search</button>
            <a class="search-btn" href="#"></a>
            
        </form>


</body>
</html>