

let search = document.getElementById("btn1")

function lookup(){
    if(search != null){
        for
        
    }

}