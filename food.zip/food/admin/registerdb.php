<?php

$conn = new mysqli('localhost','malik', '12345', 'Login');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  echo "Connected successfully";

$sql ="INSERT INTO Registration (Fullname,Username,Password) VALUES ('".$_POST['Fullname']."','".$_POST['Username']."','".$_POST['Password']."')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
  
  $conn->close();

header("refresh:2; url=register.php");
?>