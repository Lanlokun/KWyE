<?php
     include '../inc/functions.php';

     $conn = new mysqli('localhost','malik', '12345', 'foodie');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  //echo "Connected successfully";
  if(isset($_POST["submit"])) {
    $sql ="INSERT INTO combination (breakfast,lunch,dinner) VALUES ('".$_POST['breakfast']."','".$_POST['lunch']."','".$_POST['dinner']."')";
    
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
      } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }
      if (isset($_POST['calories'])) {
        
        $calories = $_POST['calories'];
        $breakfast = $_POST['breakfast'];
        $lunch = $_POST['lunch'];
        $dinner = $_POST['dinner'];
        $name = $_POST['name'];


        
    
        $data = $db_select(
            "SELECT * FROM food WHERE calories='$calories'"
        );
        $info = $db_select(
          "SELECT * FROM food WHERE name='$name'"
      );
    
        
          foreach($info as $in){
            if($breakfast == $in && $lunch == $in && $dinner == $in){
                 echo $calories;
            }
          }
        
            
            
    
        
      
      $results = [];

$conn->close();
    }}

  $q = 0;
   

    if (isset($_GET[0])) {

        $q = $_GET[0];

        $results = $db_select(
            "SELECT * FROM food WHERE id = '$q'"
        );
        
    }
     
?>

  
 


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="food.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food</title>
</head>


<header>
        <ul>
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="post.php">Post</a></li>
            <li><a href="food.php">Food</a></li>
        </ul>
<div class="logo">
            <img id="img-logo" src="logo.png">
</div>
   
</header>
<section>
<article>

   <h1 id="updates">Food Updates</h1>
   <h1 id="reccomendation"> Combinations Reccomendations</h1>
    
    <p id="para">what foods do you plan to combine today</p>
    <div class="combo">
    <form action="" method="post">
   
           
            <p>Breakfast</p>
            <input id="breakfast" type ="text"
               name = "breakfast" placeholder = "Breakfast" 
               required autofocus>
               <p>Lunch</p>
               <input id="lunch" type ="text"
               name = "lunch" placeholder = "Lunch" 
               required autofocus>
               <p>Dinner</p>
               <input id="dinner" type ="text"
               name = "dinner" placeholder = "Dinner" 
               required autofocus></br></br>
               

            <button class="log" type ="submit" name="submit">Submit</button></br></br>
            <button onclick="calcal()" id="cal" class="log" name="calories">Calories</button></br></br>
            
            
        
         </form>
        
</div>

    
    <h1>Time Table </h1>
    <table>
        <caption>Weekly Meal</caption>

       <h3>Enter date</h3> <input id="date" type="date" name="date" placeholder="date"></td>
        <tbody>
            
         <tr>
            <th>Date</th>
            <th>Breakfast</th></br></br>
            <th>Lunch</th></br>
            <th>Dinner</th></br>
            
        </tr>
        <tr>
             <td>Monday</td>
             <td><input id="monday" type="text" name="monday" placeholder="breakfast"></td>
             <td><input id="monday1" type="text" name="monday1" placeholder="lunch"></td>
             <td><input id="monday2" type="text" name="monday2" placeholder="dinner"></td>
        </tr>
        <tr>
            <td>Tuesday</td>
            <td><input id="tuesday" type="text" name="tuesday" placeholder="breakfast"></td>
            <td><input id="tuesday1" type="text" name="tuesday1" placeholder="lunch"></td>
            <td><input id="tuesday2" type="text" name="tuesday2" placeholder="dinner"></td>
        </tr>
        <tr>
             <td>Wednesday</td>
             <td><input id="wednesday" type="text" name="wednesday" placeholder="breakfast"></td>
             <td><input id="wednesday1" type="text" name="wednesday1" placeholder="lunch"></td>
             <td><input id="wednesday2" type="text" name="wednesday2" placeholder="dinner"></td>
            
        </tr>
        <tr>
             <td>Thursday</td>
             <td><input id="thursday" type="text" name="thursday" placeholder="breakfast"></td>
            <td><input id="thurday1" type="text" name="thursday1" placeholder="lunch"></td>
            <td><input id="thursday2" type="text" name="thursday2" placeholder="dinner"></td>
        </tr>
        <tr>
            <td>Friday</td>
            <td><input id="friday" type="text" name="friday" placeholder="breakfast"></td>
            <td><input id="friday1" type="text" name="friday1" placeholder="lunch"></td>
            <td><input id="friday2" type="text" name="friday2" placeholder="dinner"></td>
        </tr>
        <tr>
             <td>Saturday</td>
             <td><input id="saturday" type="text" name="saturday" placeholder="breakfast"></td>
             <td><input id="saturday1" type="text" name="saturday1" placeholder="lunch"></td>
             <td><input id="saturday2" type="text" name="saturday2" placeholder="dinner"></td>
            
        </tr>
        <tr>
             <td>Sunday</td>
             <td><input id="sunday" type="text" name="sunday" placeholder="breakfast"></td>
             <td><input id="sunday1" type="text" name="sunday1" placeholder="lunch"></td>
             <td><input id="sunday2" type="text" name="sunday2" placeholder="dinner"></td>
            
        </tr>
                
                
        
        </tbody>
    </table>
    <div class="tabutton">
    <button class="log1" type ="submit" name="tab">Submit</button></br></br>
    </div>


    
<div class="culture">
            
 <h1 id="culture">Culture</h1>
 <h5 id="tribe"> Tribes and their foods</h5>
 <div class="row">
<div class="column">
   
       <h4>Wollofs</h4>
       <p> Benachin,</p>
       <img src="Images/benachin.jpeg">
       <a href="list.php?q=<?=$result['id'] ?>" id="button">RECIPE</a>
       <aside>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
        when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
        It has survived not only five centuries, but also the leap into electronic typesetting,
         remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing 
         Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including 
         versions of Lorem Ipsum.
         </aside>
 
      
       
       <h4>Mandinkas</h4>
       <p> Domoda</p>
       <img src="Images/domoda.jpeg">
       <a href="list.php" id="button">RECIPE</a>
       <aside>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
        when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
        It has survived not only five centuries, but also the leap into electronic typesetting,
         remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing 
         Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including 
         versions of Lorem Ipsum.
         </aside>
       
       <h4>Fulas</h4>
       <p>Futi</p>
       <img src="Images/futi.jpeg">
       <a href="list.php" id="button">RECIPE</a>
       <aside>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
        when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
        It has survived not only five centuries, but also the leap into electronic typesetting,
         remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing 
         Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including 
         versions of Lorem Ipsum.
         </aside>
       <h4>Serers</h4>
       <p> yassa</p>
       <img src="Images/yassa.jpeg">
       <a href="list.php" id="button">RECIPE</a>
       <aside>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
        when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
        It has survived not only five centuries, but also the leap into electronic typesetting,
         remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing 
         Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including 
         versions of Lorem Ipsum.
         </aside>

       
       <h4>Manjagos</h4>
       <p> superkanja</p>
       <img src="Images/super.jpeg">
       <a href="dish.php" id="button">RECIPE</a>
       <aside>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
        when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
        It has survived not only five centuries, but also the leap into electronic typesetting,
         remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing 
         Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including 
         versions of Lorem Ipsum.
         </aside>


       
       <h4>Jolas</h4>
       <p> Findi,</p>
       <img src="Images/findi.jpeg">
       <a href="list.php" id="button">RECIPE</a>
       <aside>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
        when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
        It has survived not only five centuries, but also the leap into electronic typesetting,
         remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing 
         Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including 
         versions of Lorem Ipsum.
         </aside>
       
       <h4>Serahules</h4>
       <p> plasas</p>
       <img src="Images/plasas.jpeg">
       <a href="list.php" id="button">RECIPE</a>
       <aside>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
        when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
        It has survived not only five centuries, but also the leap into electronic typesetting,
         remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing 
         Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including 
         versions of Lorem Ipsum.
         </aside>
       <h4>Yorubas</h4>
       <p> Fufu</p>
       <img src="Images/dish.jpeg">
       <a href="list.php" id="button">RECIPE</a>

       <aside>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
        when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
        It has survived not only five centuries, but also the leap into electronic typesetting,
         remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing 
         Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including 
         versions of Lorem Ipsum.
         </aside>
       <h4>Akus</h4>
       <p> Bullet</p>
       <img src="Images/bullet.jpeg">
       <a href="list.php" id="button">RECIPE</a>
       <aside>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
        Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
        when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
        It has survived not only five centuries, but also the leap into electronic typesetting,
         remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing 
         Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including 
         versions of Lorem Ipsum.
         </aside>
         
      
      

</div>
</div>
</div>

    
 
 
 
   
</article>
</section>
<footer>
<h1>KNOW WHAT YOU EAT </h1>
<p>You are what you eat</p>
<img src="Images/lery.png" width="50px">
<img src="Images/cut.png" width="50px">
<img src="Images/fork.png" width="50px">
<img src="Images/spoon.png" width="50px">
</footer>
</html>